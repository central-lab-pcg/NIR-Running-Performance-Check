// ── Feature Card (feature-card-1 / AnimatedFeatureCard) ─────────────────────────
// ภาพประกอบของแต่ละเครื่องมือ (SVG ในไฟล์ ไม่โหลดรูปจากภายนอก) ใช้สีตาม --fc ของการ์ด
const FC_ART = {
  running: `<svg viewBox="0 0 160 160" aria-hidden="true"><ellipse class="sh" cx="80" cy="146" rx="52" ry="7"/><rect class="l" x="28" y="40" width="118" height="88" rx="14"/><rect class="wk" x="16" y="28" width="118" height="88" rx="14"/><path class="sd" d="M30 50H120M30 94H120"/><polyline class="sa" points="30,72 46,72 56,56 68,90 80,64 92,74 104,68 120,68"/><circle class="a" cx="68" cy="90" r="6.5" stroke="#1f1f22" stroke-width="3"/></svg>`,
  summary: `<svg viewBox="0 0 160 160" aria-hidden="true"><ellipse class="sh" cx="80" cy="146" rx="52" ry="7"/><rect class="l" x="30" y="30" width="108" height="108" rx="16" opacity=".55"/><rect class="a sk4" x="24" y="24" width="48" height="48" rx="11"/><rect class="l sk4" x="82" y="24" width="48" height="48" rx="11"/><rect class="l sk4" x="24" y="82" width="48" height="48" rx="11"/><rect class="a sk4" x="82" y="82" width="48" height="48" rx="11"/><polyline class="sw" points="37,48 45,56 59,40"/><polyline class="sw" points="95,106 103,114 117,98"/><path class="sk" d="M98 48H114M40 106H56"/></svg>`,
  bias: `<svg viewBox="0 0 160 160" aria-hidden="true"><ellipse class="sh" cx="80" cy="146" rx="56" ry="7"/><polygon class="a sk4" points="80,76 140,104 80,132 20,104"/><polygon class="l sk4" points="80,54 140,82 80,110 20,82"/><polygon class="wk" points="80,30 140,58 80,86 20,58"/><path class="sa" d="M60 58L76 50M84 66L100 58"/></svg>`,
  import: `<svg viewBox="0 0 160 160" aria-hidden="true"><ellipse class="sh" cx="80" cy="146" rx="54" ry="7"/><rect class="wk" x="48" y="22" width="64" height="76" rx="9" transform="rotate(-7 80 60)"/><path class="sl" d="M60 42H92M60 56H100M60 70H86" transform="rotate(-7 80 60)"/><rect class="l sk4" x="24" y="92" width="112" height="42" rx="11"/><path class="sk" d="M52 104H108"/><path class="sa10" d="M80 112V52"/><path class="sa10" d="M58 74L80 50L102 74"/></svg>`,
  report: `<svg viewBox="0 0 160 160" aria-hidden="true"><ellipse class="sh" cx="80" cy="146" rx="48" ry="7"/><rect class="l" x="44" y="28" width="88" height="112" rx="12"/><path class="wk" d="M36 32A12 12 0 0 1 48 20H104L124 40V124A12 12 0 0 1 112 136H48A12 12 0 0 1 36 124Z"/><path class="sk" d="M104 20V40H124"/><path class="sl" d="M52 54H100M52 68H108M52 82H88"/><path class="sa" d="M52 112c8-14 16 8 24-4s12-10 20 2"/><circle class="a" cx="112" cy="112" r="15" stroke="#1f1f22" stroke-width="4"/><polyline class="sw" points="105,112 110,117 119,107"/></svg>`,
  xchart: `<svg viewBox="0 0 160 160" aria-hidden="true"><ellipse class="sh" cx="80" cy="146" rx="52" ry="7"/><rect class="l" x="28" y="38" width="118" height="92" rx="14"/><rect class="wk" x="16" y="26" width="118" height="92" rx="14"/><path class="sd" d="M28 44H122M28 100H122"/><path class="sl" d="M28 72H122"/><polyline class="sa" points="30,76 44,60 58,86 72,66 86,94 100,52 114,78 122,70"/><circle class="a" cx="100" cy="52" r="6.5" stroke="#1f1f22" stroke-width="3"/></svg>`,
  constituent: `<svg viewBox="0 0 160 160" aria-hidden="true"><ellipse class="sh" cx="80" cy="146" rx="52" ry="7"/><rect class="l sk4" x="22" y="94" width="20" height="40" rx="5"/><rect class="l sk4" x="48" y="74" width="20" height="60" rx="5"/><rect class="a sk4" x="74" y="56" width="20" height="78" rx="5"/><circle cx="104" cy="62" r="30" fill="rgba(255,255,255,.75)" stroke="#1f1f22" stroke-width="6"/><path d="M126 84L144 102" stroke="#1f1f22" stroke-width="11" stroke-linecap="round"/><path class="sa" d="M92 50a16 16 0 0 1 16 -6"/></svg>`,
};
const FC_EXTRA_CSS = `.fc-img .wk{fill:#fff;stroke:#1f1f22;stroke-width:4;stroke-linejoin:round}.fc-img .sk4{stroke:#1f1f22;stroke-width:4;stroke-linejoin:round}.fc-img .sw{fill:none;stroke:#fff;stroke-width:6;stroke-linecap:round;stroke-linejoin:round}.fc-img .sa10{fill:none;stroke:var(--fc);stroke-width:11;stroke-linecap:round;stroke-linejoin:round}`;

function getPortalView() { try { return localStorage.getItem("nir_portal_view_v2") || "feature"; } catch (e) { return "feature"; } }
function setPortalView(v) {
  try { localStorage.setItem("nir_portal_view_v2", v); } catch (e) {}
  applyPortalView();
}
function applyPortalView() {
  const v = getPortalView();
  document.getElementById("view-switch").style.display = "inline-flex";
  document.getElementById("feature-view").style.display = v === "feature" ? "block" : "none";
  document.getElementById("cards-view").style.display = v === "feature" ? "none" : "block";
  document.querySelectorAll("#view-switch button").forEach(b => b.classList.toggle("on", b.dataset.view === v));
}
function fcEsc(s) { return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
function renderFeatureCards(u) {
  const order = TOOLS.filter(t => t.group === "view").concat(TOOLS.filter(t => t.group !== "view"));
  const card = t => {
    const i = order.indexOf(t) + 1;
    const ok = !!u.perms[t.id];
    const inner =
      '<div class="fc-glow"></div>' +
      '<div class="fc-index">' + String(i).padStart(3, "0") + '</div>' +
      '<span class="fc-state">' + fcEsc(ok ? t.tagLabel : "ไม่มีสิทธิ์") + '</span>' +
      '<div class="fc-img">' + (FC_ART[t.id] || FC_ART.running) + '</div>' +
      '<div class="fc-body"><span class="fc-tag">' + fcEsc(t.fcTag || t.name) + '</span>' +
      '<p class="fc-title">' + fcEsc(t.name) + '<span class="fc-desc">' + fcEsc(t.desc) + '</span></p></div>';
    const el = document.createElement(ok ? "a" : "div");
    el.className = "fc" + (ok ? "" : " locked");
    el.dataset.color = t.fcColor || "blue";
    el.innerHTML = inner;
    if (ok) el.href = t.url;
    else {
      el.setAttribute("role", "link"); el.setAttribute("aria-disabled", "true"); el.tabIndex = 0;
      el.onclick = () => alert("ไม่มีสิทธิ์ใช้งาน " + t.name + " — กรุณาติดต่อ Admin");
    }
    return el;
  };
  const fill = (id, list) => { const g = document.getElementById(id); g.innerHTML = ""; list.forEach(t => g.appendChild(card(t))); };
  fill("fc-grid-view", TOOLS.filter(t => t.group === "view"));
  fill("fc-grid-tools", TOOLS.filter(t => t.group !== "view"));
  applyPortalView();
}
